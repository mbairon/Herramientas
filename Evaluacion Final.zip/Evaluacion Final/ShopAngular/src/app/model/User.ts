export class User {

  username: string;
  token: string;

}
