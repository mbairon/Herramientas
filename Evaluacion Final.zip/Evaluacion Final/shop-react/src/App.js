import React, { Component } from 'react';
import './App.css';
import LoginComponent from './LoginComponent.js';

class App extends Component {

  render() {
    return (
       <LoginComponent />
    );
  }
}

export default App;
